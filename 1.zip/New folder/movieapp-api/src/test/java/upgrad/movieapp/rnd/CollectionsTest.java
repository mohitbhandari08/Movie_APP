package upgrad.movieapp.rnd;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;

public class CollectionsTest {

    private final Set<String> existingSet = new HashSet<>();

    @Before
    public void setup() {
        existingSet.add("a");
        existingSet.add("b");
        existingSet.add("c");
    }

    @Test
    public void checkDisjunction() {

        final Set<String> newSet = new HashSet<>();
        //newSet.add("d");
        //newSet.add("c");

        Collection disjunction = CollectionUtils.disjunction(existingSet, newSet);
        disjunction.size();
    }

}
