package upgrad.movieapp.service.movie.model;

public enum MovieStatus {

    PUBLISHED, RELEASED, DELETED;

}
